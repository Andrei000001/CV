package com.example.cvcherciugeorgian;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MotivationalvideosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motivationalvideos);
    }
}