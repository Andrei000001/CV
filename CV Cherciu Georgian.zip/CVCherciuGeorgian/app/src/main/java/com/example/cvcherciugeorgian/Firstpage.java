package com.example.cvcherciugeorgian;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Firstpage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firstpage);

        final Intent mainActivityIntent;
        mainActivityIntent = new Intent(Firstpage.this, MainActivity.class);


        Thread thread = new Thread(){
            public void run (){
                try {
                    sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    startActivity(mainActivityIntent);
                    finish();
                }
            }
        };
        thread.start();
    }
}